var linkedin = "https://www.linkedin.com/in/tomkingori/";
var github = "https://github.com/TomKingori";
var email = 'mailto:tomkingori66gmail.com';
var project1 = 'https://github.com/TomKingori/GA---Web-Systems-Project'
var project2 = 'https://github.com/TomKingori/Netmonitor'
var project3 = 'https://github.com/TomKingori/Subscriber-RestAPI-nodejs-express-mongodb'

whois = [
  "<br>",
  "Hey, I'm Tom.",
  "          ",
  "I'm a software engineer who builds engaging websites like this one. ",
  "I am knowledgeable in both front end and back end languages and frameworks, database",
  "management systems, version control and web hosting, while at the same time able to",
  "learn and adapt to new technologies easily.",
  "<br>",
  "I am passionate about developing innovative software that is reliable and user friendly.",
  "<br>"
];

links = [
  "<br>",
  'linkedin       <a href="' + linkedin + '" target="_blank">linkedin/tomkingori' + "</a>",
  'github         <a href="' + github + '" target="_blank">github/TomKingori' + "</a>",
  "<br>"
];

contact = [
  "<br>",
  '  Email          <span class="contacts">tomkingori66@gmail.com</span>',
  '  Phone          <span class="contacts">+254 700634204</span>',
  "<br>"
];

skills = [
  "<br>",
  '• Python          • React',
  '• HTML            • Django',
  '• CSS             • Flask',
  '• JavaScript      • Node.js',
  '• PHP             • MongoDB',
  '• MySQL           • Linux',
  "<br>",
];

projects = [
  "<br>",
  '<span class="command">Government Structure</span>       A CRUD web app documenting the current Kenyan Government',
  "                           Executive branch members built using python-Django.",
  '                           <span class="italics">(In development)</span>',
  '                           <a href="' + project1 + '" target="_blank">View Project</a>',
  "<br>",
  '<span class="command">Netmonitor</span>                 A network host and devices discovery, continuous monitoring',
  "                           and on-demand diagnostics web app built using python-Flask,",
  "                           React, Java, and Bash.",
  '                           <a href="' + project2 + '" target="_blank">View project</a>',
  "<br>",
  '<span class="command">Subscriber REST API</span>        A REST API that creates, updates, deletes and  fetches',
  "                           subscribers built using Node.js, Express.js and MongoDB.",
  '                           <a href="' + project3 + '" target="_blank">View Project</a>',
  "<br>"
];

help = [
  "<br>",
  '<span class="command">whois</span>          Who is Tom?',
  '<span class="command">skills</span>         A list of my skills',
  '<span class="command">projects</span>       View coding projects',
  '<span class="command">links</span>          Display social networks',
  '<span class="command">contact</span>        Contact me',
  "<br>",
  '<span class="command">history</span>        View command history',
  '<span class="command">help</span>           You obviously already know what this does',
  '<span class="command">clear</span>          Clear terminal',
  '<span class="command">banner</span>         Display the header',
  "<br>",
];

banner = [
  '<span class="index">TomKing (TK) is Not A Corporation. No Rights Reserved.</span>',
  "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~",

    "   _______                     __ __  _                              _",
    "  /_   __\/____   ____ ___     / //_/ (_)____   ____ _ ____   _____  (_)",
    "    / /  / __ \\ / __ `__ \\   / ,<   / // __ \\ / __` // __ \\ / ___/ / / ",
    "   / /  / /_/ // / / / / /  / /| | / // / / // /_/ // /_/ // /    / /  ",
    "  /_/   \\____//_/ /_/ /_/  /_/ |_|/_//_/ /_/ \\__, / \\____//_/    /_/   ",
    "                                            /____/           © 2022  ",
    "   ",
    "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~",
    '<span class="color2">Welcome to my interactive web terminal.</span>',
  "<span class=\"color2\">For a list of available commands, type</span> <span class=\"command\">'help'</span><span class=\"color2\">.</span>",
];

